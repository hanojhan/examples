<?php
require 'C:/Users/Abrar Kamboh/vendor/autoload.php';

use Aws\S3\S3Client;

use Aws\Exception\AwsException;


		$username =$_POST['name1'];

		$file_name = $_FILES['image']['name'];   
		$temp_file_location = $_FILES['image']['tmp_name'];



		
		$s3 = new Aws\S3\S3Client([
			'region'  => 'ap-south-1',
			'version' => 'latest',
			'credentials' => [
				'key'    => "AKIATXKF5BTX5N7EAGNQ",
				'secret' => "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",
			]
		]);		

		$result = $s3->putObject(array(
			'Bucket' => 'kambohpic',
			'Key'    => $file_name,
			'SourceFile' => $temp_file_location,
				
		));


	
	?>


<html>
<head>
</head>
<body bgcolor ="#F6EBE8">
<h1 align="center" style="color:blue;"> UPLOAD MORE PHOTOS </h1>
<center>
<form name="myform" action="upload1.php" onsubmit="" method="post" enctype="multipart/form-data">


<img src="img.png" width="100" height="100"><br>
SELECT IMAGE 2<br>
	<input type="file" name="image1" onchange="readURL1(this);" placeholder="SELECT IMAGE"></input><br><br>
<img src="img.png" width="100" height="100"><br>
SELECT IMAGE 3<br>
	<input type="file" name="image2" onchange="readURL2(this);" placeholder="SELECT IMAGE"></input><br><br>
<input name ="var1" value="<?php echo $file_name; ?>">
	<button type="submit" id="submit" name="submit" value="submit"><img src="pic.png" width="100" height="100">
		UPLOAD   </button>
</form>
<img id="blah" src="#" width="100" height="100"><br>
</center>

<script>
function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah')
                    .attr('src', e.target.result)
                    .width(150)
                    .height(200);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
</script>
</html>