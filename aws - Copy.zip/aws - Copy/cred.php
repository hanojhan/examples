<?php
if (ENVIRONMENT == 'production') {
 define('AWS_S3_KEY', 'AKIATXKF5BTX5N7EAGNQ');
 define('AWS_S3_SECRET', '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');
 define('AWS_S3_REGION', 'Asia Pacific (Mumbai)');
 define('AWS_S3_BUCKET', 'kambohpic');
 define('AWS_S3_URL', 'http://s3.'.AWS_S3_REGION.'.amazonaws.com/'.AWS_S3_BUCKET.'/');
}
?>
