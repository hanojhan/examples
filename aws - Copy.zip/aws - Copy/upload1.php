<?php
require 'C:/Users/Abrar Kamboh/vendor/autoload.php';


use Aws\S3\S3Client;

use Aws\Exception\AwsException;

		
$f= $_POST['var1'];

		$file_name1 = $_FILES['image1']['name'];   
		$temp_file_location1 = $_FILES['image1']['tmp_name']; 
	

		$file_name2 = $_FILES['image2']['name'];   
		$temp_file_location2 = $_FILES['image2']['tmp_name'];


		
		$s3 = new Aws\S3\S3Client([
			'region'  => 'ap-south-1',
			'version' => 'latest',
			'credentials' => [
				'key'    => "AKIATXKF5BTX5N7EAGNQ",
				'secret' => "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",
			]
		]);	

		if(empty($file_name1) || empty($file_name2)){

			
		}	
		else{

		$result = $s3->putObject(array(
			'Bucket' => 'kambohpic',
			'Key'    => $file_name1,
			'SourceFile' => $temp_file_location1,
				
		));

		$result = $s3->putObject(array(
			'Bucket' => 'kambohpic',
			'Key'    => $file_name2,
			'SourceFile' => $temp_file_location2,
				
		));

}
	
	?>

	<html>
	<head>


	</head>
 	<body bgcolor ="#F6EBE8">
			<h1 align="center" style="color:blue;"> Continue to Display </h1>
<form name="myform" action="display.php" onsubmit="" method="post" enctype="multipart/form-data">
<input name ="var2" value="<?php echo $f; ?>">	
<input name ="var3" value="<?php echo $file_name1; ?>">
<input name ="var4" value="<?php echo $file_name2; ?>">		
	<button type="submit" id="submit" name="submit" value="submit"><img src="arrow.jpg" width="200" height="200">
		UPLOAD   </button>
		</form>
	</body>
	</html>