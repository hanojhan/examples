<html>
<head>


</head>
<body bgcolor ="#F6EBE8">
                <h1  align="center" style="color:blue;"> Welcome </h1><br><br><br>
<?php

require 'C:/Users/Abrar Kamboh/vendor/autoload.php';


use Aws\S3\S3Client;

use Aws\Exception\AwsException;

$f1= $_POST['var2'];
$f2= $_POST['var3'];
$f3= $_POST['var4'];

$s3 = new Aws\S3\S3Client([
            'region'  => 'ap-south-1',
            'version' => 'latest',
            'credentials' => [
                'key'    => "AKIATXKF5BTX5N7EAGNQ",
                'secret' => "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",
            ]
        ]); 

try {
    // Get the object.
    $result1 = $s3->getObject([
        'Bucket' => 'kambohpic',
        'Key'    => $f1
            ]);

 

} catch (S3Exception $e) {
    echo $e->getMessage() . PHP_EOL;
}

try {
    // Get the object.
    $result2 = $s3->getObject([
        'Bucket' => 'kambohpic',
        'Key'    => $f2
            ]);

 

} catch (S3Exception $e) {
    echo $e->getMessage() . PHP_EOL;
}

try {
    // Get the object.
    $result3 = $s3->getObject([
        'Bucket' => 'kambohpic',
        'Key'    => $f3
            ]);

 

} catch (S3Exception $e) {
    echo $e->getMessage() . PHP_EOL;
}
?>
<img  align="left" style="width: 500; height:500;  " 
 src="data:image/jpeg;base64,<?php echo base64_encode($result1['Body'])?>" alt=""><br><br><br><br><br>
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

 <img  style="width: 250; height:250; " 
 src="data:image/jpeg;base64,<?php echo base64_encode($result2['Body'])?>" alt="">

  <img  style="width: 250; height:250; " 
 src="data:image/jpeg;base64,<?php echo base64_encode($result1['Body'])?>" alt="">


 <img  style="width: 250; height:250; " 
 src="data:image/jpeg;base64,<?php echo base64_encode($result3['Body'])?>" alt="">
</body>
</html>