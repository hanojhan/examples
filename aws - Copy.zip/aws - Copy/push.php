<?php 


$tmpfile = $_FILES['file']['tmp_name'];
$file = $_FILES['file']['name'];

if (defined('AWS_S3_URL')) {
  // Persist to AWS S3 and delete uploaded file
  require_once('S3.php');
  S3::setAuth(AWS_S3_KEY, AWS_S3_SECRET);
  S3::setRegion(AWS_S3_REGION);
  S3::setSignatureVersion('v4');
  S3::putObject(S3::inputFile($tmpfile), AWS_S3_BUCKET, 'path/in/bucket/'.$file, S3::ACL_PUBLIC_READ);
  unlink($tmpfile);
} 
else 
 // Persist to disk
 $path = 'path/to/user/files/'.$file;
 move_uploaded_file($tmpfile, $path);


?>